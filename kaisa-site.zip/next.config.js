/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    // allow local gifs
    unoptimized: true,
  },
};

export default nextConfig;
