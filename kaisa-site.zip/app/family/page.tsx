import Image from "next/image";
import Link from "next/link";
import { LayoutFrame } from "@/components/LayoutFrame";
import { RetroBox } from "@/components/RetroBox";
import { site } from "@/lib/site";

export default function FamilyPage() {
  const a = site.about;

  return (
    <LayoutFrame active="/family">
      <div className="familyGrid">
        <aside>
          <RetroBox title="## NAVIGATION">
            <div className="jump">
              {a.items.map((it) => (
                <div key={it.id} style={{ marginBottom: 6 }}>
                  <a href={`#${it.id}`}>{it.name}</a>
                </div>
              ))}
              <div style={{ marginTop: 10 }}>
                <Link href="/">Home</Link>
              </div>
            </div>
          </RetroBox>

          <div style={{ height: 12 }} />

          <RetroBox>
            <Image
              src="/media/family.png"
              alt="family photo placeholder"
              width={260}
              height={180}
              style={{ border: "2px solid rgba(255,255,255,0.25)", background: "rgba(0,0,0,0.25)" }}
            />
            <p className="muted" style={{ marginTop: 8 }}>
              Meet the Family and old friends (mutta kaisaversio).
            </p>
          </RetroBox>
        </aside>

        <section>
          <RetroBox>
            <h2 style={{ margin: 0, fontSize: 18 }}>{a.title}</h2>
            <p className="muted">{a.subtitle}</p>
            <p className="muted">Under construction, jokainen saa oman pienen tekstinsä + kuvan.</p>
          </RetroBox>

          <div style={{ height: 12 }} />

          {a.items.map((it) => (
            <div key={it.id} id={it.id} style={{ marginBottom: 12 }}>
              <RetroBox>
                <div className="card">
                  <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
                    <Image
                      src="/media/avatar.png"
                      alt={`${it.name} placeholder`}
                      width={96}
                      height={96}
                      style={{ border: "2px solid rgba(255,255,255,0.25)", background: "rgba(0,0,0,0.25)" }}
                    />
                    <div>
                      <h3 className="cardTitle">{it.name}</h3>
                      <div className="muted">Age: {it.age}</div>
                      <p className="p" style={{ marginTop: 8 }}>{it.desc}</p>
                    </div>
                  </div>
                </div>
              </RetroBox>
            </div>
          ))}

          <RetroBox>
            <p className="p">{a.footer}</p>
          </RetroBox>
        </section>
      </div>
    </LayoutFrame>
  );
}
