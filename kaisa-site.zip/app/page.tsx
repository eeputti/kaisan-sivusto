import Image from "next/image";
import Link from "next/link";
import { LayoutFrame } from "@/components/LayoutFrame";
import { RetroBox } from "@/components/RetroBox";
import { site } from "@/lib/site";

export default function HomePage() {
  const h = site.home;

  return (
    <LayoutFrame active="/">
      <div className="homeGrid">
        <aside>
          <RetroBox title={h.whatsNewTitle}>
            <p className="p">{h.whatsNew}</p>
            <p className="muted">{h.todo}</p>
          </RetroBox>

          <div style={{ height: 12 }} />

          <RetroBox title="Links">
            <p className="p" style={{ marginBottom: 6 }}>
              {h.links.map((l, i) => (
                <span key={l.label}>
                  <a href={l.href} target="_blank" rel="noreferrer">
                    {l.label}
                  </a>
                  {i < h.links.length - 1 ? " " : ""}
                </span>
              ))}
            </p>
          </RetroBox>

          <div style={{ height: 12 }} />

          <RetroBox title={h.latestAlbumTitle}>
            <Image
              src="/media/album.png"
              alt="album cover placeholder"
              width={240}
              height={240}
              style={{ border: "2px solid rgba(255,255,255,0.25)", background: "rgba(0,0,0,0.25)" }}
            />
            <div className="hr" />
            <div className="p" style={{ marginBottom: 2 }}>{h.latestAlbumName}</div>
            <div className="muted" style={{ marginBottom: 10 }}>{h.latestAlbumDate}</div>
            <div className="muted">Tracklist:</div>
            <ol className="list">
              {h.latestAlbumTracks.map((t) => (
                <li key={t}>{t}</li>
              ))}
            </ol>
          </RetroBox>

          <div style={{ height: 12 }} />

          <RetroBox title={h.featuredGifTitle}>
            <div className="featured">
              <Image
                src="/media/featured.gif"
                alt="featured gif"
                width={120}
                height={120}
                style={{ border: "2px solid rgba(255,255,255,0.25)", background: "rgba(0,0,0,0.25)" }}
              />
              <div>
                <div className="p" style={{ marginBottom: 2 }}>{h.featuredGifCaption}</div>
                <div className="muted">vaihda /public/media/featured.gif</div>
              </div>
            </div>

            <div className="buttons">
              <Link className="btn88" href="/family"><span>family</span></Link>
              <Link className="btn88" href="/gear"><span>gear</span></Link>
              <Link className="btn88" href="/resources"><span>resources</span></Link>
            </div>

            <div style={{ marginTop: 10 }}>
              <Image src="/media/button-static.png" alt="static button" width={88} height={31} />
              {" "}
              <Image src="/media/button-anim.gif" alt="animated button" width={88} height={31} />
            </div>
          </RetroBox>
        </aside>

        <section>
          <RetroBox>
            <p className="p"><strong>Pet (Kaisa)</strong></p>
            <p className="p">
              tää on synttärisivu. se on pieni, mutta tarkka. ja tässä on se geocities-fiilis.
              vaihda tekstit <code>lib/site.ts</code> ja kuvat <code>/public/media</code>.
            </p>
            <p className="p">
              <strong>Latest video</strong> (placeholder): linkkaa tähän joku teidän video / clip / tai vaikka google photos -albumi.
            </p>
            <p className="p">
              <a href="https://youtu.be/" target="_blank" rel="noreferrer">https://youtu.be/</a>
            </p>
            <p className="p">
              i&apos;m glad we could share this day together
              {" "}
              <Image src="/media/vhs.gif" alt="" width={28} height={28} style={{ verticalAlign: "middle" }} />
            </p>
            <div>
              <Image src="/media/hg.gif" alt="" width={28} height={28} />
              {" "}
              <Image src="/media/8.gif" alt="" width={28} height={28} />
              {" "}
              <Image src="/media/g.gif" alt="" width={28} height={28} />
              {" "}
              <Image src="/media/homer.gif" alt="" width={28} height={28} />
              {" "}
              <Image src="/media/a.gif" alt="" width={28} height={28} />
              {" "}
              <Image src="/media/wii.gif" alt="" width={28} height={28} />
            </div>

            <div className="hr" />

            <p className="p"><strong>Contact</strong></p>
            <p className="p">löydät mut: <a href="https://instagram.com/" target="_blank" rel="noreferrer">instagram</a> tai mail: <a href="mailto:hello@example.com">hello@example.com</a></p>
          </RetroBox>
        </section>
      </div>
    </LayoutFrame>
  );
}
