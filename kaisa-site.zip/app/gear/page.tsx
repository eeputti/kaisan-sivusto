import Image from "next/image";
import { LayoutFrame } from "@/components/LayoutFrame";
import { RetroBox } from "@/components/RetroBox";
import { site } from "@/lib/site";

export default function GearPage() {
  const g = site.gear;

  return (
    <LayoutFrame active="/gear">
      <div className="homeGrid" style={{ gridTemplateColumns: "1fr" }}>
        <RetroBox>
          <h2 style={{ margin: 0, fontSize: 18 }}>{g.title}</h2>
          <p className="muted">{g.subtitle}</p>
          <p className="muted">mallisivussa tää on lista kameroista. meillä tää on lista meidän jutuista.</p>
        </RetroBox>

        {g.sections.map((s) => (
          <RetroBox key={s.title}>
            <div style={{ display: "flex", gap: 12, alignItems: "flex-start", flexWrap: "wrap" }}>
              <Image
                src="/media/gear.png"
                alt="gear placeholder"
                width={220}
                height={160}
                style={{ border: "2px solid rgba(255,255,255,0.25)", background: "rgba(0,0,0,0.25)" }}
              />
              <div style={{ flex: 1, minWidth: 240 }}>
                <h3 style={{ margin: "0 0 6px 0" }}>{s.title}</h3>
                <p className="p">{s.body}</p>
                <p className="muted">vinkki: vaihda kuva + lisää 1 gif per osio</p>
              </div>
            </div>
          </RetroBox>
        ))}

        <RetroBox>
          <Image src="/media/fish.gif" alt="" width={28} height={28} />
          {" "}
          <Image src="/media/shark.gif" alt="" width={28} height={28} />
        </RetroBox>
      </div>
    </LayoutFrame>
  );
}
