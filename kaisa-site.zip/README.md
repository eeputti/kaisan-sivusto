# kaisa-site 💛

Geocities-henkinen synttärisivusto Next.js:llä (GitHub + Vercel).

## Local dev
```bash
npm install
npm run dev
```

## Deploy
- pushaa GitHubiin
- tuo repo Verceliin → Deploy

## Muokkaa sisältöä
- `lib/site.ts`
- kuvat/gifit: `public/media/*`
